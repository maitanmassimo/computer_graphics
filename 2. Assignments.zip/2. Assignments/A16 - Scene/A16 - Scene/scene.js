function drawSceneTree(S) {
	computeWorldMatrix(0, S, utils.identityMatrix());
}

function computeWorldMatrix(index, S, father_world_matrix){
	console.log("computeWorldMatrix called on node " + index);
	var T = utils.MakeTranslateMatrix(S[index][0], S[index][1], S[index][2]);
	var R_z =  utils.MakeRotateZMatrix(S[index][5]);
	var R_x = utils.MakeRotateXMatrix(S[index][3]);
	var R_y = utils.MakeRotateYMatrix(S[index][4]);
	var k = 0;
	var M_local = utils.multiplyMatrices(
					utils.multiplyMatrices(
						utils.multiplyMatrices(T,R_z), R_x), R_y);			
	var M_node = utils.multiplyMatrices(father_world_matrix, M_local);					
	if(S[index][6]!=-1 && S[index][7]!=-1){
		for(k = S[index][6]; k <= S[index][7]; k++){
			computeWorldMatrix(k, S, M_node);
		}
	}			
	draw(index, M_node);
}