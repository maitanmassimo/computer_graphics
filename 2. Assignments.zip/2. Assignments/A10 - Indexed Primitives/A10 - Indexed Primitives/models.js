function round(value, decimals) {
  return Number(Math.round(value+'e'+decimals)+'e-'+decimals);
}

function buildGeometry() {
	var i;
	
	var DIM = 50; //how many points we want to sample in each direction from the origin. 
	var NORMAL_FACTOR = 3; // we want it to be between -3 and 3
	
	// Draws function y = sin(x) * cos(z) with -3 <= x <= 3 and -3 <= z <= 3.
	///// Creates vertices
	
	
	var vert2 = [];
	for( i = -DIM; i <= DIM; i++){
		for(j = -DIM; j <= DIM; j++){			
			x = i*NORMAL_FACTOR/DIM;
			z = j*NORMAL_FACTOR/DIM;
			y = Math.cos(x)*Math.sin(z);		
			vert2[(i+DIM)*2*DIM+(i+DIM)+(j+DIM)] = [x, y, z];			
		}
	}
	
	////// Creates indices
	var ind2 = [];
	for(i = 0; i < 2*DIM; i++) {
		for(j = 0; j < 2*DIM; j++) {
			ind2[6*(i*2*DIM+j)  ] = (2*DIM+1)*j+i;					
			ind2[6*(i*2*DIM+j)+1] = (2*DIM+1)*j+i+1;			
			ind2[6*(i*2*DIM+j)+2] = (2*DIM+1)*(j+1)+i+1;	
			ind2[6*(i*2*DIM+j)+3] = (2*DIM+1)*j+i;
			ind2[6*(i*2*DIM+j)+4] = (2*DIM+1)*(j+1)+i+1;
			ind2[6*(i*2*DIM+j)+5] = (2*DIM+1)*(j+1)+i;
		}
	}
	
	console.log(vert2)
	console.log(ind2);
	
	var color2 = [0.0, 0.0, 1.0];
	addMesh(vert2, ind2, color2);


	// Draws a Half Sphere
	///// Creates vertices
	
	var SPHERE_RAY = 2;
	
	var circumf_quantum = 180;
	var ray_quantum = 18;
	var current_angle = 0;
	var vert3 = [];
	
	for(i = ray_quantum; i >= 0; i--) {
		for(j = 0 ; j < circumf_quantum; j++) {
			current_angle = (2*Math.PI*j/circumf_quantum);
			console.log("ray "+ i*SPHERE_RAY/ray_quantum + ", angle " + (current_angle*180/(Math.PI)));
			//console.log("cos("+current_angle+") = " + Math.cos(current_angle) + " = " + (Math.cos(current_angle)).toFixed(3));
			//console.log("sin("+current_angle+") = " + Math.sin(current_angle)+ " = " + (Math.sin(current_angle)).toFixed(3));
			x = ((i*SPHERE_RAY*Math.cos(current_angle))/ray_quantum).toFixed(3);
			z = ((i*SPHERE_RAY*Math.sin(current_angle))/ray_quantum).toFixed(3);
			console.log( "i = " + i + ", j = " + j + ", x = "+ x +", z = " + z);
			//console.log( "x^2 +z^2 +y^2= " + (Math.pow(x, 2)+Math.pow(z,2)) + +Math.pow(y,2));
			console.log("(" + SPHERE_RAY + ")^2 - " + x + "^2 - "+z+ "^2 = " + 
								(Math.pow((SPHERE_RAY),2)) + " - " + (Math.pow(x,2)) + " - " +(Math.pow(z,2))+" = " 
								
								+	(Math.pow((SPHERE_RAY),2)-Math.pow(x,2)-Math.pow(z,2)).toFixed(2)					
			);							
			y = Math.sqrt((Math.pow((SPHERE_RAY),2)-Math.pow(x,2)-Math.pow(z,2)).toFixed(2));
			console.log( "x^2 +z^2 +y^2= " + (Math.pow(x, 2)+Math.pow(z,2) +Math.pow(y,2)));
			vert3[(ray_quantum-i)*circumf_quantum+j] = [x, y, z];
		}
	}
	
	console.log(vert3);
	////// Creates indices
	var ind3 = [];
	for(i = 0; i < ray_quantum; i++)  {
		for(j = 0 ; j < circumf_quantum; j++)  {
			ind3[6*(i*circumf_quantum+j)  ] = (j+(circumf_quantum)*i+1)-(Math.floor((j+1)/circumf_quantum)*circumf_quantum);					
			ind3[6*(i*circumf_quantum+j)+1] = j+(circumf_quantum)*i;			
			ind3[6*(i*circumf_quantum+j)+2] = (circumf_quantum)*(i+1)+j;	
			ind3[6*(i*circumf_quantum+j)+3] =  (circumf_quantum)*(i+1)+j;	
			ind3[6*(i*circumf_quantum+j)+4] = ((circumf_quantum)*(i+1)+j+1)-(Math.floor((j+1)/circumf_quantum)*circumf_quantum);//%(circumf_quantum*(i+1)); //(circumf_quantum)*(i+1)+j;	
			ind3[6*(i*circumf_quantum+j)+5] = (j+(circumf_quantum)*i+1)-(Math.floor((j+1)/(circumf_quantum))*circumf_quantum);//%(circumf_quantum*(i+1));
		}
		
	}
	
	
	
	console.log(ind3);
	/*
	for(i = 0; i < 2; i++) {
		for(j = 0; j < 2; j++) {
			ind3[6*(i*2+j)  ] = 3*j+i;
			ind3[6*(i*2+j)+1] = 3*j+i+1;
			ind3[6*(i*2+j)+2] = 3*(j+1)+i+1;
			ind3[6*(i*2+j)+3] = 3*j+i;
			ind3[6*(i*2+j)+4] = 3*(j+1)+i+1;
			ind3[6*(i*2+j)+5] = 3*(j+1)+i;
		}
	}
	*/
	var color3 = [0.0, 1.0, 0.0];
	addMesh(vert3, ind3, color3);
}

